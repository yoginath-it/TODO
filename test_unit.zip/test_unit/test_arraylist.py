import unittest

class ArrayList:
    def __init__(self):
        self.data = []

    def append(self, value):
        self.data.append(value)

    def get(self, index):
        if index < 0 or index >= len(self.data):
            raise IndexError("Index out of bounds")
        return self.data[index]

    def size(self):
        return len(self.data)

class TestArrayList(unittest.TestCase):
    def setUp(self):
        self.array_list = ArrayList()
        self.array_list.append(1)
        self.array_list.append(2)
        self.array_list.append(3)

    def test_get_existing_index(self):
        self.assertEqual(self.array_list.get(0), 1)
        self.assertEqual(self.array_list.get(1), 2)
        self.assertEqual(self.array_list.get(2), 3)

    def test_get_out_of_bounds_index(self):
        with self.assertRaises(IndexError):
            self.array_list.get(-1)  # negative index
        with self.assertRaises(IndexError):
            self.array_list.get(3)   # index equal to size
        with self.assertRaises(IndexError):
            self.array_list.get(10)  # index greater than size

    def test_get_empty_array_list(self):
        empty_list = ArrayList()
        with self.assertRaises(IndexError):
            empty_list.get(0)

    def test_get_last_index(self):
        last_index = self.array_list.size() - 1
        self.assertEqual(self.array_list.get(last_index), 3)

    def test_size(self):
        self.assertEqual(self.array_list.size(), 3)

if __name__ == '__main__':
    unittest.main()

